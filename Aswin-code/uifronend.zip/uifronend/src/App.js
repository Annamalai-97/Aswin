import logo from './logo.svg';
import './App.css';
import { From } from './component/myFrom';
import { Application } from './component/form';
import { Route, Routes } from 'react-router-dom';
import { Data2 } from './component/useStatefunction';

function App() {
  return (
    <Routes>
      <Route path='' element={<Data2/>}/>
      <Route path='/myform' element={<From/>}/>
      <Route path='/register/:id' element={<Application/>}/>
      <Route path='/dataform'/>
    </Routes>
  );
}

export default App;
