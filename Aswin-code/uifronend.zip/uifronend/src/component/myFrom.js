import axios from "axios";
import React, { useEffect, useState } from "react";
import { useFormState } from "react-dom";
export const From = () => {
  const [name,setName] = useState();
  const [age, setAge] = useState([]);
  // const [password, setPassword] = useState();
  // const [phnumber, setPhnumber] = useState();
  // const [gender, setGender] = useState();
  // const [address, setAddress] = useState();
  function submitData(e){
    e.preventDefault()
    // console.log(name)
    axios.post('http://localhost:8080/api/addstudent',name).then((response)=>console.log(response))
  }
  const getdata=async()=>{
    const data= await axios.get('http://localhost:8080/api/getuser').catch(error=>{console.log(error)})
    setAge(data.data)

  }
  useEffect(()=>{
    getdata()
  },[])
  console.log(age)
  return (
    <div>
    <form>
      Name
      <input type="text" name="name" onChange={(e)=>{setName({...name,[e.target.name]:e.target.value})}} />
      Age
      <input type="number" name="age" onChange={(e)=>{setName({...name,[e.target.name]:e.target.value})}} />
      Password
      <input type="password" name="password" onChange={(e)=>{setName({...name,[e.target.name]:e.target.value})}} />
      Phnumber
      <input type="number" name="phnumber" onChange={(e)=>{setName({...name,[e.target.name]:e.target.value})}}/>
      Gender
      <span>
        <input type="radio" value="male" name="gender" onChange={(e)=>{setName({...name,[e.target.name]:e.target.value})}} />
        &nbsp;
        <b>Male</b>
      </span>
      <span style={{ marginRight: "10px" }}>
        <input type="radio" value="female" name="gender" onChange={(e)=>{setName({...name,[e.target.name]:e.target.value})}} />
        &nbsp;
        <b>Female</b>
      </span>
      Address
      <textarea name="address" onChange={(e)=>{setName({...name,[e.target.name]:e.target.value})}}></textarea>
      <button onClick={(e)=>submitData(e)}>Submit</button>
    </form>
    <table>
      <thead>
        <tr>
          <th>Name</th>
          <th>Age</th>
          <th>Phnumber</th>
          <th>Gender</th>
        </tr>
      </thead>
      <tbody>
        {age?.map((value,key)=>{<tr key={key+1}>
          <td>{value.name}</td>
          <td>{value.age}</td>
          <td>{value.phnumber}</td>
          <td>{value.gender}</td>
        </tr>})}
      </tbody>
    </table>
    </div>
  );
};
