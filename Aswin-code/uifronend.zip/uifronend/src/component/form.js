import axios from "axios";
import React, { useEffect, useState } from "react";
import { useFormState } from "react-dom";
import { useParams } from "react-router-dom";

export const Application=()=>{
    const [name,setName]=useState();
    function appsubmit(e){
        e.preventDefault()
        axios.post('http://localhost:8080/api/addstudent',name).then((response)=>console.log(response))
    }
    const getdata=async()=>{
        const File=axios.get('http://localhost:8080/api/getdata').catch(error=>{console.log(error)})
        console.log(File)    
      }
      useEffect(()=>{
          getdata()
        },[])
        const{id}=useParams()
        console.log(id)
    return(
        <form>
            Name<input type="text" name="name" onChange={(e)=>{setName({...name,[e.target.name]:e.target.value})}}/>
            Age<input type="num" name="age" onChange={(e)=>{setName({...name,[e.target.name]:e.target.value})}}/>
            Email<input type="text" name="email" onChange={(e)=>{setName({...name,[e.target.name]:e.target.value})}}/>
            Contact<input type="num" name="contact" onChange={(e)=>{setName({...name,[e.target.name]:e.target.value})}}/>
            Data Of Birth<input type="num" name="dob" onChange={(e)=>{setName({...name,[e.target.name]:e.target.value})}}/>
            Gender
            <span>
            <input type="radio" value="female" name="gender" onChange={(e)=>{setName({...name,[e.target.name]:e.target.value})}}/>&nbsp;
            <b>Female</b>
            </span>
            <span>
            <input type="radio" value="male" name="gender" onChange={(e)=>{setName({...name,[e.target.name]:e.target.value})}}/>&nbsp;
            <b>Male</b>
            </span>
            Dpartment<input type="text" name="department" onChange={(e)=>{setName({...name,[e.target.name]:e.target.value})}}/>
            University<input type="text" name="university" onChange={(e)=>{setName({...name,[e.target.name]:e.target.value})}}/>
            <button onClick={(e)=>appsubmit(e)}>Submit</button>
        </form>
    )
}