import axios from "axios";
import react, { useState } from "react";
export const Data2 = () => {
  const [value, setValue] = useState({});
  console.log(value);
  axios
    .get("http://127.0.0.1:8000/api/get-attendance/", {
      headers: {
        "Content-Type": "application/json",
      }
    })
    .then((response) => console.log(response.data))
    .catch((error) => console.error("CORS Error:", error));

const [getData,setgetData]=useState({})

    const SubmitData=(e)=>{
      axios.post(`http://127.0.0.1:8000/api/submit/`,value).then((response)=>{
        console.log(response)
      }).catch(error=>console.error(error))
    }

  return (
    <div>
      <input
        type="text"
        name="name"
        onChange={(e) => {
          const value1 = e.target.value;
          setValue({ ...value, [e.target.name]: value1 });
        }}
      />
      <input
        type="text"
        name="age"
        onChange={(e) => {
          const value1 = e.target.value;
          setValue({ ...value, [e.target.name]: value1 });
        }}
      />
      <input
        type="text"
        name="location"
        onChange={(e) => {
          const value1 = e.target.value;
          setValue({ ...value, [e.target.name]: value1 });
        }}
      />
      <div>
        <button onClick={(e)=>{SubmitData(e)}}>Submit</button>
      </div>
    </div>
  );
};
