import React, { useState } from "react";
import { useFormState } from "react-dom";

export const File=()=>{
    const [name,setName]=useState()
    const [age,setAge]=useState()
    function collect(e){
        e.preventDefault()
        axios.post('http://localhost:8080/api/addstudent',name).then((response)=>console.log(response))
      }
      const getcollect=async()=>{
        const coll=axios.get('http://localhost:8080/api/getcollect').catch(error=>{console.log(error)})
        console.log(coll)
    
      }
      useEffect(()=>{
        getcollect()
      },[])
      console.log(age)
    return(
        <div>
        <form>
            Name<input type="text" name="name" onChange={(e)=>{setName({...name,[e.target.name]:e.target.value})}} />
            Age<input type="number" name="age" onChange={(e)=>{setName({...name,[e.target.name]:e.target.value})}} />
            Password<input type="password" name="password" onChange={(e)=>{setName({...name,[e.target.name]:e.target.value})}} />
            Address
            <textarea name="address" onChange={(e)=>{setName({...name,[e.target.name]:e.target.value})}}></textarea>
            <button onClick={(e)=>collect(e)}>Submit</button>
        </form>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Address</th>
                </tr>
            </thead>
            <tbody>
            {age?.map((value,key)=>{<tr key={key+1}>
          <td>{value.name}</td>
          <td>{value.age}</td>
          <td>{value.address}</td>
        </tr>})}
            </tbody>
        </table>
        </div>

    )
}