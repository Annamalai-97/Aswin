import Image from "next/image";
import MyFullCalendar from "./components/calendar";
export default function Home() {
  return (
    <MyFullCalendar/>
   );
}
