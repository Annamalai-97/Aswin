import react, { useState } from "react";

export const Form = ()=>{
    console.log('forms')
    const [file,setFile] = useState()
    const getfile=(e)=>{
        console.log(e.target.files[0])
    }
    return(
        <div>
            <form>
                <input type="file" onChange={(e)=> getfile(e)} ></input>
                <button>Submit</button>
            </form>
        </div>
    )    
}