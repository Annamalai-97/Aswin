import logo from './logo.svg';
import './App.css';
import { Routes } from 'react-router-dom';
import { Route } from 'react-router-dom';
import { Mag1 } from './Newproject/np3';
import { Mag } from './Newproject/np2';
import { Maggi } from './Newproject/np1';
import { Map } from './Newproject/map';
import { Sam1 } from './Newproject/sample1';
import { Form } from './Forms/form';
import { Provider } from 'react-redux';
import store from './Redux/store/store';


function App() {
  return (
    <div>
      <Provider store = {store}>
      <Routes>
      <Route path='' element={<Mag1/>}  />
      <Route path='/screen2' element={<Mag/>} />
      <Route path='/screen3/:age' element={<Maggi/>} />
      <Route path='/map' element={<Map/>} />
      <Route path='/sam' element={<Sam1/>}/>
      <Route path='/form' element={<Form/>} />
    </Routes>
    </Provider>
    </div>
  );
}

export default App;
