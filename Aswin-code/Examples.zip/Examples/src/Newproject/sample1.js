import axios from "axios";
import React, { useEffect, useState } from "react";

export function Sam1(){
    const[start,setStart] = useState()
    const[value,setValue] = useState([])
    console.log("sam1",value)
    const postdata = async()=>{
        axios.post("http://127.0.0.1:8000/api/postdata/",start).then(response=>{
            console.log(response)
        })
    }
    const[begin,setBegin] = useState([])
    const getdata = async()=>{
        const data = await axios.get("http://127.0.0.1:8000/api/getdata/")
        setBegin(data.data)
    }
    useEffect(()=>{
        getdata()
    },[])

    const getdatabyid = async(e)=>{
        const id = e.target.id
        const data = await axios.get(`http://127.0.0.1:8000/api/getdatabyid/${id}`) 
        setValue(data.data)
        
    }

    const posteditdata = (e)=>{
        const id=e.target.id;
        axios.put(`http://127.0.0.1:8000/api/editdata/${id}`,value).then(response=>console.log(response))
    }

    const deletedata = (e)=>{
        const id = e.target.id;
        axios.delete(`http://127.0.0.1:8000/api/deletedata/${id}`).then(response=>console.log(response))
    }
    return(
        <div>
            <p>hi</p>
            <label>Name</label> <input type="text" name="name" onChange={(e)=> {const value1 = e.target.value; setStart({...start,[e.target.name]:value1})}} />
            <label>location</label><input type="text" name="location" onChange={(e)=> {const value1 = e.target.value; setStart({...start,[e.target.name]:value1})}}/>
            <label>phone</label><input type="number" name="phone" onChange={(e)=> {const value1 = e.target.value; setStart({...start,[e.target.name]:value1})}}/>
            <br/>
            <button onClick={postdata} >Submit</button>
            <div>
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Location</th>
                            <th>Phone</th>
                        </tr>
                    </thead>
                    <tbody>
                        {begin.map((value,key)=>(<tr key={key+1}>
                            <td>{value.name}</td>
                            <td>{value.location}</td>
                            <td>{value.phone}</td>
                            <td><button onClick={(e)=>getdatabyid(e)} id = {value.id}>Edit</button></td>
                            <td><button onClick={(e)=>deletedata(e)} id = {value.id}>Delete</button></td>
                        </tr>))}
                    </tbody>
                </table>
                {/* {value.map((value,key)=>( */}

                <div>
                <input type="text" name="name" value={value.name?value.name:'' } onChange={(e)=> {const value1 = e.target.value; setValue({...value,[e.target.name]:value1})}} />
                    <input type="text" name="location" value={value.location?value.location:''} onChange={(e)=> {const value1 = e.target.value; setValue({...value,[e.target.name]:value1})}}/>
                    <input type="number" name="phone" value={value.phone?value.phone:''} onChange={(e)=> {const value1 = e.target.value; setValue({...value,[e.target.name]:value1})}}/>
                    <button id={value.id?value.id:''} onClick={(e)=>posteditdata(e)}>Submit</button>
                </div> 
                {/* ))}   */}
            </div>
        </div>
    )
} 
