import React from "react";
import { useState } from "react";
import { Magparent } from "./np3.1";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";


export function Mag1(){
    const [start,setStart] = useState()
    const navigate = useNavigate()
    console.log("Bid Data")
    const data = useSelector((state)=>state.data)
    console.log(data)
    return(
        <div>
            <input type="text" name="Name" onChange={(e)=> {const value1 = e.target.value; setStart({...start,[e.target.name]:value1})}} />
            <input type="text" name="Age" onChange={(e)=> {const value1 = e.target.value; setStart({...start,[e.target.name]:value1})}} />

            <Magparent name={start&&start.Name?start.Name:" "} age={start&&start.Age?start.Age:" "} />

            <button onClick={()=>navigate(`/screen2`)} >Click to navigate</button>

        </div>
    )
}