import React from "react";
import { useState } from "react";

export function Magparent({name,age}){
    const [state,setState] = useState()
    return(
        <div>
            <table>
                <thead>
                    <tr>
                        <td>Name</td>
                        <td>Age</td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>{name}</td>
                        <td>{age}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    )
}