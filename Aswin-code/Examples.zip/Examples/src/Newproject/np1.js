import React from "react";
import { useParams } from "react-router-dom";

export function Maggi(){
    console.log("yes")
    const {age} = useParams()
    return(
        <div>
            <p>Hi hello{age}</p>
        </div>
    )
}