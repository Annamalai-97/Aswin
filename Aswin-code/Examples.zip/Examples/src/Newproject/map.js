import React from "react";
import { useState } from "react";


export function Map(){
    const dictionary = [
        {name:"maggi",age:21},
        {name:"mag",age:24}
    ]

    return(
        <div>
            {dictionary.map((value,key)=>( <div key={key+1}>
                <h1>{value.name}</h1>
                <h1>{value.age}</h1>
            </div>))}
        </div>
    )
}