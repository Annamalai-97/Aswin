import React from "react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

export function Mag(){
    const [start,setStart] = useState()
    const navigate = useNavigate()
    console.log("correct")
    return(
        <div>
            <input type="text" onChange={(e)=> setStart(e.target.value)} />
            <button onClick={()=> navigate(`/screen3/56`)} >Click her</button>
        </div>
    )
}