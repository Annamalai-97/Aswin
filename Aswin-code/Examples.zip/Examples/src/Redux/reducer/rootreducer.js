import { combineReducers } from "redux";
import Datareducer from "./datareducer";

export default combineReducers({
        data: Datareducer, // ✅ Ensure correct key

})