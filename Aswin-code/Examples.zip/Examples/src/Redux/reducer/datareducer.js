import { setData } from "../constant";

const Datareducer = (data  = [] , action) => {
    switch(action.type){
        case setData:
            return[...action.data]
    }
}
export default Datareducer;

