import { put, takeEvery } from "redux-saga/effects"
import { Data, setData } from "../constant"
import axios from "axios"

function * getdatasaga(){
    const data = yield axios.get('http://127.0.0.1:8000/api/getdata/')
    const data1 = data.data;
    yield put({
        type : setData,
        data1 
    }) 
}
function * exportdata(){
    yield takeEvery(Data,getdatasaga)
}

export default exportdata;
