import createSagaMiddleware from "redux-saga";
import rootreducer from "../reducer/rootreducer";
import { configureStore, getDefaultMiddleware } from "@reduxjs/toolkit";
import exportdata from "../apisaga/datasaga";

const SagaMiddleware = createSagaMiddleware();
const store = configureStore({
    reducer: rootreducer,
    middleware : (getDefaultMiddleware)=>getDefaultMiddleware({thank:false}).concat(SagaMiddleware)
})
SagaMiddleware.run(exportdata)

export default store;
