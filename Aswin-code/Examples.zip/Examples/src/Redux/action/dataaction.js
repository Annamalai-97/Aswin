import { Data, setData } from "../constant";

export const GetData = (data) => {
    return {
        type:Data,
        payload:data
    }
}